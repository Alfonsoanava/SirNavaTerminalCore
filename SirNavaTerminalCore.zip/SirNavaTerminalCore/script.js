function triggerAgent() {
  const status = document.getElementById("status");
  const responseBox = document.getElementById("agentResponse");

  status.innerText = "Agent Online";
  responseBox.innerHTML = `
    <p>Hello, Sir Nava. I’m SecureBot. All systems are operational and standing by.</p>
    <p>Ready for your next command...</p>
  `;
}